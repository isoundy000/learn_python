## Trigger Subscribe from Procedure

This example demonstrates how a registered procedure upon being called can dynamically subscribe to a topic.

Asked on SO [here](http://stackoverflow.com/questions/25330339/can-autobahn-twisted-wamp-application-do-pub-sub).
