# Autobahn Testsuite Testee

This is an asyncio-based testee for testing against [Autobahn|Testsuite](http://autobahn.ws/testsuite).